<?php  
    define('CONSUMER_KEY', 'X0CQlGfqCkoCs6U5KOBxTfiap');
    define('CONSUMER_SECRET', 'AFgPgV4dPbGkKcxQaKIsCjvhrHETJHQsPZ31szNT7B9JvlWumr');
    define('OAUTH_CALLBACK', 'http://twitter.alampatawebsolution.a2hosted.com/callback.php');
?>